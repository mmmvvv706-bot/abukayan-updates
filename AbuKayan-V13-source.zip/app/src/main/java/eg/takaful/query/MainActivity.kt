package eg.takaful.query

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * A convenience app for the OFFICIAL Takaful/Karama inquiry website.
 * It never processes or transmits national IDs except through the official web page.
 * Online config affects local presentation ONLY (title, notice, button label, color).
 * The government URL and developer contact destination cannot be remotely overridden.
 */
class MainActivity : Activity() {
    companion object {
        private const val OFFICIAL_URL = "https://tk.moss.gov.eg/"
        private const val CONTACT_URL = "https://wa.me/201129096755"
        // Replace this URL ONCE with a publicly readable HTTPS config.json location.
        // Example: https://raw.githubusercontent.com/OWNER/REPO/main/config.json
        private const val REMOTE_CONFIG_URL = "https://raw.githubusercontent.com/mmmvvv706-bot/abukayan-updates/main/config.json"
        private const val CACHE_KEY = "last_verified_config"
        private const val MAX_CONFIG_BYTES = 8192
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var titleText: TextView
    private lateinit var noticeText: TextView
    private lateinit var contactButton: Button
    private lateinit var mainHeader: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 31, 61)
        setContentView(R.layout.activity_main)

        // Android 15 (targetSdk 35) draws app content behind system navigation.
        // Reserve the actual gesture/3-button navigation-bar inset so the
        // WhatsApp contact button is NEVER covered by system controls.
        // This works with changing navigation modes and device rotations.
        val rootContainer = findViewById<View>(R.id.rootContainer)
        val originalBottomPadding = rootContainer.paddingBottom
        rootContainer.setOnApplyWindowInsetsListener { view, insets ->
            val navigationBarBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            } else {
                @Suppress("DEPRECATION")
                insets.systemWindowInsetBottom
            }
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                originalBottomPadding + navigationBarBottom
            )
            insets
        }
        rootContainer.requestApplyInsets()

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        titleText = findViewById(R.id.titleText)
        noticeText = findViewById(R.id.noticeText)
        contactButton = findViewById(R.id.contactButton)
        mainHeader = findViewById(R.id.mainHeader)

        webView.settings.apply {
            javaScriptEnabled = true // Required by official portal.
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            builtInZoomControls = true
            displayZoomControls = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                if (uri.scheme == "https" && isOfficialHost(uri.host)) return false
                return openExternally(uri)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                statusText.text = "بوابة الوزارة الرسمية"
                progressBar.visibility = View.GONE
            }
            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    statusText.text = "تعذّر فتح الموقع. تأكد من الإنترنت واضغط تحديث."
                    progressBar.visibility = View.GONE
                }
            }
        }

        findViewById<Button>(R.id.reloadButton).setOnClickListener {
            if (webView.url.isNullOrEmpty()) webView.loadUrl(OFFICIAL_URL) else webView.reload()
            fetchOnlineConfig() // refresh online presentation whenever the user taps reload
        }
        findViewById<Button>(R.id.backButton).setOnClickListener { navigateBack() }
        contactButton.setOnClickListener { openExternally(Uri.parse(CONTACT_URL)) }
        findViewById<Button>(R.id.hotlinesButton).setOnClickListener { showHotlinesDialog() }
        findViewById<Button>(R.id.aboutButton).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("حول التطبيق — أبو كيان V13")
                .setMessage("يساعدك التطبيق على الوصول إلى بوابة الاستعلام التابعة لوزارة التضامن الاجتماعي.\n\nالتطبيق مستقل وغير تابع رسميًا لوزارة التضامن الاجتماعي.\n\nلا يجمع التطبيق الرقم القومي أو يخزنه؛ تُدخل البيانات مباشرة في بوابة الوزارة.")
                .setPositiveButton("حسنًا", null)
                .show()
        }

        // Show last downloaded public settings immediately, including when offline.
        getPreferences(MODE_PRIVATE).getString(CACHE_KEY, null)?.let { applyConfig(it) }
        fetchOnlineConfig()

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(OFFICIAL_URL)
    }

    /** Network work is off the UI thread; invalid or unavailable config is safely ignored. */
    private fun fetchOnlineConfig() {
        val endpoint = REMOTE_CONFIG_URL.trim()
        val uri = Uri.parse(endpoint)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) return
        Thread {
            var conn: HttpURLConnection? = null
            try {
                val stamp = System.currentTimeMillis()
                val url = URL(endpoint + if (endpoint.contains('?')) "&t=$stamp" else "?t=$stamp")
                conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.useCaches = false
                conn.setRequestProperty("Accept", "application/json")
                if (conn.responseCode !in 200..299) return@Thread
                val length = conn.contentLength
                if (length > MAX_CONFIG_BYTES) return@Thread
                val configText = conn.inputStream.use { stream ->
                    val result = ByteArrayOutputStream()
                    val buffer = ByteArray(2048)
                    while (true) {
                        val count = stream.read(buffer)
                        if (count == -1) break
                        result.write(buffer, 0, count)
                        if (result.size() > MAX_CONFIG_BYTES) return@Thread
                    }
                    result.toString("UTF-8")
                }
                // Validate the document before caching or rendering it.
                val data = JSONObject(configText)
                if (data.optInt("schema_version", -1) != 1) return@Thread
                getPreferences(MODE_PRIVATE).edit().putString(CACHE_KEY, configText).apply()
                runOnUiThread { if (!isFinishing && !isDestroyed) applyConfig(configText) }
            } catch (_: Exception) {
                // No error banners; the official inquiry continues to work as usual.
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    private fun applyConfig(jsonText: String) {
        try {
            val config = JSONObject(jsonText)
            if (config.optInt("schema_version", -1) != 1) return
            val newTitle = config.optString("title", "استعلام تكافل وكرامة").trim().take(50)
            val announcement = config.optString("announcement", "").trim().take(180)
            val accent = config.optString("accent_color", "#0E615B")
            titleText.text = newTitle.ifEmpty { "استعلام تكافل وكرامة" }
            contactButton.text = "تواصل عبر واتساب" // No phone number in the UI, including after remote config refresh.
            if (announcement.isBlank()) {
                noticeText.visibility = View.GONE
            } else {
                noticeText.text = announcement
                noticeText.visibility = View.VISIBLE
            }
            // Only accept an explicit opaque RGB hex color to avoid malformed settings.
            if (Regex("^#[0-9a-fA-F]{6}$").matches(accent)) {
                // V12 keeps its navy-and-gold visual identity regardless of V9 remote accent.
            }
        } catch (_: Exception) {
            // Invalid config is not fatal.
        }
    }

    /** Verified public contact numbers from the Ministry of Social Solidarity website.
     * The user explicitly chooses each number. ACTION_DIAL never places a call directly.
     * Numbers are deliberately not controlled by the remote configuration file.
     */
    private fun showHotlinesDialog() {
        val entries = listOf(
            Pair("الخط الساخن لتكافل وكرامة", "19680"),
            Pair("الخط الساخن لوزارة التضامن الاجتماعي", "16439"),
            Pair("منظومة الشكاوى الحكومية الموحدة", "16528"),
            Pair("بطاقة الخدمات المتكاملة (ذوو الإعاقة)", "15044"),
            Pair("بنك ناصر الاجتماعي", "16868"),
            Pair("الجمعيات والعمل الأهلي", "17673"),
            Pair("هاتف وزارة التضامن الاجتماعي (1)", "33375467"),
            Pair("هاتف وزارة التضامن الاجتماعي (2)", "33375390")
        )
        val display = entries.map { (label, number) -> "$label\n☎ $number" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("أرقام التواصل والخطوط الساخنة — اضغط للاتصال")
            .setItems(display) { _, index ->
                val number = entries[index].second
                // Cairo/Giza geographic landlines need area code 02 from mobile phones.
                val dial = if (number == "33375467" || number == "33375390") "02$number" else number
                try {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", dial, null)))
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(this, "لا يوجد تطبيق اتصال متاح", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun isOfficialHost(host: String?): Boolean {
        val normalized = host?.lowercase(Locale.ROOT) ?: return false
        return normalized == "moss.gov.eg" || normalized.endsWith(".moss.gov.eg")
    }

    private fun openExternally(uri: Uri): Boolean {
        if (uri.scheme != "https" && uri.scheme != "http") return true
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "تعذّر فتح الرابط الخارجي", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun navigateBack() {
        if (webView.canGoBack()) webView.goBack() else finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = navigateBack()

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
