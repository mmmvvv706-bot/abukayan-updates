# Abu Kayan – Takaful/Karama Inquiry V9

Android application with a small dialer directory of public social-solidarity hotlines and the official inquiry portal. Independent from the Egyptian ministry. Reads public UI settings from GitHub; personal national ID numbers are handled only by the official web portal. See README-AR.md for details.
