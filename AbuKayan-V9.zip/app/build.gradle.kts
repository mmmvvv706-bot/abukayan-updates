plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "eg.takaful.query"
    compileSdk = 35
    defaultConfig {
        applicationId = "eg.takaful.query"
        minSdk = 24
        targetSdk = 35
        versionCode = 9
        versionName = "9.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
